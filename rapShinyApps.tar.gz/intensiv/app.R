# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "intensiv", package = "intensiv")
setwd(dir)
shiny::shinyAppDir(".")
