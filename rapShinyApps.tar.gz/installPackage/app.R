# author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "installPackage", package = "raptools")
setwd(dir)
shiny::shinyAppDir(".")
