# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "korona", package = "korona")
setwd(dir)
shiny::shinyAppDir(".")
