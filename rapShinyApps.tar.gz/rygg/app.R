# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "rygg", package = "rygg")
setwd(dir)
shiny::shinyAppDir(".")
