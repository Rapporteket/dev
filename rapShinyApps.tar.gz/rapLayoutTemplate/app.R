# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "rapLayoutTemplate", package = "raptools")
setwd(dir)
shiny::shinyAppDir(".", options = list(display.mode="showcase"))
