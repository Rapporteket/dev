# app author: are.edvardsen@helse-nord.no
ltmv::run_app()
