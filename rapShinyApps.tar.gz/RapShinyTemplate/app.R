# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "RapShinyTemplate", package = "raptools")
setwd(dir)
shiny::shinyAppDir(".")
