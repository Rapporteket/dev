# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "noric", package = "noric")
setwd(dir)
shiny::shinyAppDir(".")
